import json
import os
import uuid
import boto3
import requests
from bs4 import BeautifulSoup
from google.oauth2 import service_account
from googleapiclient.discovery import build
from markdownify import markdownify as md # Thư viện chuyển HTML sang Markdown

# --- CẤU HÌNH ---
S3_BUCKET = os.environ.get('S3_BUCKET_NAME')
s3_client = boto3.client('s3')

# Google Creds
try:
    GOOGLE_API_CREDENTIALS = json.loads(os.environ.get('GOOGLE_CREDENTIALS', '{}'))
except json.JSONDecodeError:
    GOOGLE_API_CREDENTIALS = {}
SCOPES = ['https://www.googleapis.com/auth/documents.readonly']

def get_aws_blog_markdown(url):
    """Trích xuất HTML và chuyển sang Markdown."""
    if not url or not url.startswith('http'):
        return None, "Invalid URL"
    try:
        response = requests.get(url, timeout=15)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # Lấy nội dung chính của AWS Blog
        article_body = soup.select_one('article .blog-post-content')
        if not article_body:
            return None, "Content not found"

        # Chuyển đổi HTML sang Markdown
        # heading_style='ATX' để ra format # Header thay vì gạch chân
        markdown_text = md(str(article_body), heading_style="ATX", strip=['script', 'style'])
        return markdown_text.strip(), None
    except Exception as e:
        return None, str(e)

def get_google_doc_text(url):
    """Giữ nguyên logic lấy text từ Google Docs của bạn."""
    if not url or 'docs.google.com/document/d/' not in url:
        return None, "Invalid Google Doc URL"
    try:
        if not GOOGLE_API_CREDENTIALS:
            return None, "Missing Google Credentials"
        
        creds = service_account.Credentials.from_service_account_info(
            GOOGLE_API_CREDENTIALS, scopes=SCOPES)
        service = build('docs', 'v1', credentials=creds)
        document_id = url.split('/d/')[1].split('/')[0]
        document = service.documents().get(documentId=document_id).execute()
        
        content = document.get('body', {}).get('content')
        doc_text = ''
        if content:
            for value in content:
                if 'paragraph' in value:
                    elements = value.get('paragraph', {}).get('elements', [])
                    for elem in elements:
                        if 'textRun' in elem:
                            doc_text += elem.get('textRun', {}).get('content', '')
        return doc_text.strip(), None
    except Exception as e:
        return None, str(e)

def upload_to_s3(content, folder, file_name):
    """Hàm upload đơn giản lên S3."""
    key = f"{folder}/{file_name}"
    s3_client.put_object(
        Bucket=S3_BUCKET,
        Key=key,
        Body=content.encode('utf-8'),
        ContentType='text/markdown' if folder == 'original' else 'text/plain'
    )
    return key

def lambda_handler(event, context):
    """
    Input: SQS Event
    Output: List of objects chứa S3 Keys (để pass sang Step Function)
    """
    processed_results = []
    
    print(f"Processing {len(event.get('Records', []))} records.")

    for record in event.get('Records', []):
        try:
            payload = json.loads(record.get('body', '{}'))
            aws_url = payload.get('aws_blog_url')
            doc_url = payload.get('google_doc_url')
            
            # 1. Trích xuất
            aws_md, aws_err = get_aws_blog_markdown(aws_url)
            doc_text, doc_err = get_google_doc_text(doc_url)
            
            if aws_err or doc_err:
                print(f"Error extracting: AWS={aws_err}, Doc={doc_err}")
                continue # Skip lỗi
            
            # 2. Tạo ID duy nhất cho bài viết này
            article_id = str(uuid.uuid4())[:8]
            
            # 3. Upload lên S3
            # Lưu bài gốc vào folder 'original'
            original_key = upload_to_s3(aws_md, 'original', f"{article_id}.md")
            # Lưu bài dịch vào folder 'translated'
            translated_key = upload_to_s3(doc_text, 'translated', f"{article_id}.txt")
            
            # 4. Chuẩn bị output cho Step Function
            processed_results.append({
                "article_id": article_id,
                "s3_bucket": S3_BUCKET,
                "original_key": original_key,
                "translated_key": translated_key,
                "urls": {
                    "aws": aws_url,
                    "doc": doc_url
                }
            })
            
        except Exception as e:
            print(f"Critical error processing record: {e}")
            continue

    # Trả về danh sách để Step Function (Map state) có thể lặp qua
    return {
        "status": "success",
        "data": processed_results
    }